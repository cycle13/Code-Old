#include "Poco/File.h"
#include "config.h"

bool generate_pngdata(Poco::File& cur, UploadInfo& upinfo);