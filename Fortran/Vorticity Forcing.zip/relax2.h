C     Program :Using spectral method to get inverse Laplacian       
CC#include "/diska/hlin/qgmodel/force/spect.f"                                                                   
	   include "spect.f"                                                                   
cc   ip=1: divergence and velocity potential,input u,v
cc   ip=2: vorticity and stream function,    input u,v
cc   ip=3: input:pot, output td (72,37)
CC   The sign of the result needs to be reversed

	subroutine relax1(um,vm,pot,td,ip)
C                                                                    
      PARAMETER(ILG=64,ILG1=ILG+1,ILATH=16,ILAT=2*ILATH)                    
      PARAMETER(L=73,M=37,N=3,LM1=L-1,NP1=N+1,NM1=N-1)
      PARAMETER(LEN=300,LEN2=210,LEN3=LEN2*N)
      PARAMETER(NY=23)
      COMPLEX DFLUX(LEN,5),DVM(LEN,N),DTM(LEN,NM1),dvminv(len),
     *   vorinv(len)
      COMPLEX DTMINV(LEN,NM1),TEM(LEN,NM1),VOR(LEN)                    
      COMPLEX SA(LEN),SB(LEN),SC(LEN),SD(LEN),WRKL(2000)                        
      COMPLEX SE(LEN,N),SF(LEN,N),VFOR(LEN,N),TFOR(LEN,N)
      COMPLEX SM(LEN,9),SFORC(LEN,6)
      REAL EPSI(LEN),ALP(LEN),DALP(LEN),WRKS(LEN)                               
      REAL FGG(ILG1,ILAT,5),DFGG(ILG1,ILAT,N),DTGG(ILG1,ILAT,NM1)
      REAL SL(ILAT),WL(ILAT),SIA(ILAT),RAD(ILAT),WOCS(ILAT)
      REAL DLAT(ILAT),slat(ilat),AZ(5)
      REAL P1(NP1),P2(N),DP1(N),DP2(NM1),SIGMA(NM1)
      REAL CM(L,M,18:19),fll(l,m),td(72,37)
      REAL UFM25(L,M),VFM25(L,M)
      real u25(72,37),v25(72,37),u50(72,37),v50(72,37),
     * u85(72,37),v85(72,37)
	real u(72,37),v(72,37),um(72,37),vm(72,37),tdg(ILG,ILAT)
      REAL GG(ILG1,ILAT),cvfgg(ilg1,ilat),pot(72,37),pot1(l,m)
      REAL AGG(ILG1,ILAT,9:10)
      REAL UFG25(ILG1,ILAT),VFG25(ILG1,ILAT)
      REAL RE(LEN2,N),RF(LEN2,N)
      INTEGER LSR(2,LEN),INDX(10),INDEX(LEN2),IRC(LEN2)
      CHARACTER INPUT(65:88)*6,CH(27)*32,output(65:88)*6,cvf(66:88)*9
      COMMON /WORK1/G,R,CP,PI,EARTH,CRAD
      COMMON /WORK2/DLAM,DPHI,RDLAM,RDPHI,DX(M),DY
     2 ,PHI(M),COR(M),RCOS(M),RSIN(M)
      EQUIVALENCE (CM(1,1,18),UFM25)
      EQUIVALENCE (CM(1,1,19),VFM25)
      EQUIVALENCE (AGG(1,1,9),UFG25)
      EQUIVALENCE (AGG(1,1,10),VFG25)
      EQUIVALENCE (FGG(1,1,1),DFGG)
      EQUIVALENCE (DFLUX(1,1),DVM)
      EQUIVALENCE (SFORC(1,1),VFOR)
C
      DATA P1/100.0,400.0,700.0,1000.0/,P2/250.0,550.0,850.0/
      DATA SIGMA/3.73E-2,2.27E-2/
      DATA OMEGA/7.292E-5/


      DATA INDX/4,5,6,7,11,12,13,14,18,19/
C                                                                               
c     OPEN(6,FILE='PRINT.OUT')
cc      REWIND 6
C

      CALL CONST1
      CALL CONST2(-90.0,90.0,5.0)
C
C
      OMEG2=2.0*OMEGA                                                           
      RAD2=EARTH*EARTH                                                          
C                                                                               
C     DEFINE AND CALCULATE PARAMETERS IN THE SPECTRAL DOMAIN                    
C                                                                               
      LRLMT=21212
      CALL DIMGT(LSR,LA,LR,LM,KTR,LRLMT)                                        
      IF(LEN.LT.LSR(2,LM+1)-1)THEN                                              
ccccccc      WRITE(6,*)'LEN IS TOO SMALL',LEN                                          
      STOP 9                                                                    
      ENDIF                                                                     
      CALL EPSCAL(EPSI,LSR,LM)                                                  
      IR=LM-1                                                                   
   11 FORMAT(1X,3I5)                                                            
   12 FORMAT(1X,10E12.4)                                                        
C                                                                               
C     CALCULATE CONSTANTS FOR THE GAUSSIAN GRID                                 
C                                                                               
      CALL GAUSSG(ILATH,SL,WL,SIA,RAD,WOCS)                                     
      CALL TRIGL(ILATH,SL,WL,SIA,RAD,WOCS)
C
C     DLAT IS THE LATITUDE (IN DEGREES) OF THE CURRENT
C     GAUSSIAN ROW
C
      DO 96 J=1,ILAT
      DLAT(J)=180.0*RAD(J)/PI
      slat(j) = dlat(j) + 90.
   96 CONTINUE                                      
C
C
C     FIND FROM LSR ADDRESSES OF DESIRED MODES
C
      DO 43 IJ=1,LEN2
      INDEX(IJ)=0
      IRC(IJ)=0
   43 CONTINUE
      KOUNT=0
      DO 61 I=1,LM
      MN1=LSR(1,I)
      MN2=LSR(1,I+1)-1
      MS=I-1
      DO 61 MN=MN1,MN2
      NS=MS+MN-MN1
C
C     MODES ANTISYMMETRIC TO THE EQUATOR
C
      IF(MOD(MS+NS,2).EQ.1)THEN
C
C     ADDRESS OF THE REAL PART
C
      KOUNT=KOUNT+1
      INDEX(KOUNT)=MN
      IRC(KOUNT)=1
C
C     ADDRESS OF THE IMAGINARY PART FOR A NONZONAL COMPONENT
C

      IF(MS.NE.0)THEN
      KOUNT=KOUNT+1
      INDEX(KOUNT)=MN
      IRC(KOUNT)=2
      ENDIF
      ENDIF
   61 CONTINUE
      NINDEX=KOUNT
   91 FORMAT(1X,24I5)
      IF(NINDEX.NE.LEN2)THEN
      WRITE(6,*)'WRONG LEN2'
      STOP 9
      ENDIF
C

      DO 14 K=1,9
      DO 14 IJ=1,LA
      SM(IJ,K)=(0.0,0.0)
   14 CONTINUE

cc  Reverse ,Let J=1 at south pole
	do 22 j=1,37
	j1=38-j
	 do 23 i=1,72
	pot1(i,j)=pot(i,j1)
	ufm25(i,j)=um(i,j1)
23	vfm25(i,j)=vm(i,j1)
22	pot1(l,j)=pot1(1,j)
	if(ip.eq.3)go to 83
cccccccccccccccccccccccccccccccccccccccccc
c
C
C     ASSIGN VALUES TO THE NORTH POLE
C
      M225=46
      MH=(M+1)/2
c    MH = 37 corresponds to equator 
      DO 75 KK=9,10
      DO 75 I=1,LM1
	CM(I,1,INDX(KK))=0.0
        CM(I,M,INDX(KK))=0.0
   75 CONTINUE
C
      DO 79 KK=9,10
      DO 79 J=1,M 
      CM(L,J,INDX(KK))=CM(1,J,INDX(KK))
   79 CONTINUE
C
C     INTERPOLATION TO THE GAUSSIAN GRID AND THEN
C     CALCULATE THE DIVERGENCE SPECTRALLY
C
      DO 80 KK=9,10
      CALL LLIGG(AGG(1,1,KK),ILG1,ILAT,DLAT
     1 ,CM(1,1,INDX(KK)),L,M,3)

C
C     SET FOR REQUIRED GWAQD INPUT FORM: U*COS(LAT)/RAD & V*COS(LAT)/RAD
C     WITH MINUS SIGN FOR CALCULATIONS OF FLUX CONVERGENCE
C
      DO 80 J=1,ILAT
      DO 80 I=1,ILG1
      AGG(I,J,KK)=-AGG(I,J,KK)*SIA(J)/EARTH
   80 CONTINUE
C
      CALL GWAQD(VOR,DVM(1,1),LSR,LM,UFG25,VFG25,ILG1,ILAT,SL,WOCS
     1 ,ALP,DALP,EPSI,WRKS,WRKL)
C
ccc  Velocity potential
	if(ip.eq.1)then
c      call stagg (cvfgg,ilg1,ilat,1,sl,dvm,lsr,lm,la,
c     *            alp,epsi,wrks,wrkl) 
      call invlap (dvm(1,1),dvminv,lsr,lm)
      call stagg (gg,ilg1,ilat,1,sl,dvminv,lsr,lm,la,
     *            alp,epsi,wrks,wrkl)
	endif
ccc  Stream function
	if(ip.eq.2)then
c	call stagg (cvfgg,ilg1,ilat,1,sl,vor,lsr,lm,la,
c     *            alp,epsi,wrks,wrkl)
      call invlap (vor,vorinv,lsr,lm)
      call stagg (gg,ilg1,ilat,1,sl,vorinv,lsr,lm,la,
     *            alp,epsi,wrks,wrkl)
        endif
ccc

83	if(ip.eq.3)then
	 CALL LLIGG(GG,ILG1,ILAT,DLAT
     1 ,pot1,L,M,3)
	call GGAST (vor,LSR,LM,LA, GG,ILG1,ILAT,1,SL,WL,
     *   ALP,EPSI,WRKS,WRKL) 
	call invlap (vor,vorinv,lsr,lm)
      call stagg (gg,ilg1,ilat,1,sl,vorinv,lsr,lm,la,
     *            alp,epsi,wrks,wrkl)
        endif
CC Convert to Grid point
      call ggill (fll,l,m,gg,ilg1,ilat,slat,3)

cc  Reverse ,Let J=1 at 90
      do 66 j = 1,37
	j1=38-j
	do 66 i = 1,72
      td(i,j) = fll(i,j1)
   66 continue
	
	return
      END                                                                       

C
      SUBROUTINE CONST1
      COMMON /WORK1/G,R,CP,PI,EARTH,CRAD
      G=9.81
      R=287.0
      CP=1004.0
      PI=4.0*ATAN(1.0)
      EARTH=6370949.0
      CRAD=PI/180.0
      RETURN
      END
C
      SUBROUTINE CONST2(PHI1,PHI2,DELAM)
      PARAMETER(M=37)
      COMMON /WORK1/G,R,CP,PI,EARTH,CRAD
      COMMON /WORK2/DLAM,DPHI,RDLAM,RDPHI,DX(M),DY
     2 ,PHI(M),COR(M),RCOS(M),RSIN(M)
      DLAM=DELAM
      DPHI=(PHI2-PHI1)/(M-1)
      RDLAM=CRAD*DLAM
      RDPHI=CRAD*DPHI
      DO 11 J=1,M
      PHI(J)=PHI1+(J-1)*DPHI
      PHI(J)=PHI(J)*CRAD
      RCOS(J)=COS(PHI(J))
      RSIN(J)=SIN(PHI(J))
      DX(J)=RDLAM*EARTH*RCOS(J)
      COR(J)=2.0*7.292E-5*RSIN(J)
   11 CONTINUE
      DY=RDPHI*EARTH
      RETURN
      END
