C     Program :Using spectral method to do spatial filtering
cc Sardeshmak and Hoskins JAS (1984)

c#include "/diska/hlin/qgmodel/force/spect.f"                                                                   
cc   ip=1: divergence and velocity potential,input u,v
cc   ip=2: vorticity and stream function,    input u,v
cc   ip=3: input:pot, output td (72,37)
	subroutine spacefilter(um,td)
C                                                                    
      PARAMETER(ILG=64,ILG1=ILG+1,ILATH=16,ILAT=2*ILATH)                    
      PARAMETER(L=73,M=37,N=3,LM1=L-1,NP1=N+1,NM1=N-1)
      PARAMETER(LEN=300,LEN2=210,LEN3=LEN2*N)
      PARAMETER(NY=23)
      COMPLEX DFLUX(LEN,5),DVM(LEN,N),DTM(LEN,NM1),dvminv(len),
     *   vorinv(len)
      COMPLEX DTMINV(LEN,NM1),TEM(LEN,NM1),VOR(LEN)                    
      COMPLEX SA(LEN),SB(LEN),SC(LEN),SD(LEN),WRKL(2000)                        
      COMPLEX SE(LEN,N),SF(LEN,N),VFOR(LEN,N),TFOR(LEN,N)
      COMPLEX SM(LEN,9),SFORC(LEN,6)
      REAL EPSI(LEN),ALP(LEN),DALP(LEN),WRKS(LEN)                               
      REAL FGG(ILG1,ILAT,5),DFGG(ILG1,ILAT,N),DTGG(ILG1,ILAT,NM1)
      REAL SL(ILAT),WL(ILAT),SIA(ILAT),RAD(ILAT),WOCS(ILAT)
      REAL DLAT(ILAT),slat(ilat),AZ(5)
      REAL P1(NP1),P2(N),DP1(N),DP2(NM1),SIGMA(NM1)
      REAL CM(L,M,18:19),fll(l,m),td(73,37)
      REAL UFM25(L,M),VFM25(L,M)
      real u25(72,37),v25(72,37),u50(72,37),v50(72,37),
     * u85(72,37),v85(72,37)
	real u(72,37),v(72,37),um(73,37),vm(72,37),tdg(ILG,ILAT)
      REAL GG(ILG1,ILAT),cvfgg(ilg1,ilat),pot(72,37),pot1(l,m)
      REAL AGG(ILG1,ILAT,9:10)
      REAL UFG25(ILG1,ILAT),VFG25(ILG1,ILAT)
      REAL RE(LEN2,N),RF(LEN2,N)
      INTEGER LSR(2,LEN),INDX(10),INDEX(LEN2),IRC(LEN2)
      CHARACTER INPUT(65:88)*6,CH(27)*32,output(65:88)*6,cvf(66:88)*9
      COMMON /WORK1/G,R,CP,PI,EARTH,CRAD
      COMMON /WORK2/DLAM,DPHI,RDLAM,RDPHI,DX(M),DY
     2 ,PHI(M),COR(M),RCOS(M),RSIN(M)
      EQUIVALENCE (CM(1,1,18),UFM25)
      EQUIVALENCE (CM(1,1,19),VFM25)
      EQUIVALENCE (AGG(1,1,9),UFG25)
      EQUIVALENCE (AGG(1,1,10),VFG25)
      EQUIVALENCE (FGG(1,1,1),DFGG)
      EQUIVALENCE (DFLUX(1,1),DVM)
      EQUIVALENCE (SFORC(1,1),VFOR)
C
      DATA P1/100.0,400.0,700.0,1000.0/,P2/250.0,550.0,850.0/
      DATA SIGMA/3.73E-2,2.27E-2/
      DATA OMEGA/7.292E-5/

      DATA INDX/4,5,6,7,11,12,13,14,18,19/
C                                                                               
      OPEN(6,FILE='PRINT.OUT')
      REWIND 6
C
      CALL CONST1
      CALL CONST2(-90.0,90.0,5.0)
C
C
      OMEG2=2.0*OMEGA                                                           
      RAD2=EARTH*EARTH                                                          
C                                                                               
C     DEFINE AND CALCULATE PARAMETERS IN THE SPECTRAL DOMAIN                    
C                                                                               
c      LRLMT=21212
      LRLMT=21212
      CALL DIMGT(LSR,LA,LR,LM,KTR,LRLMT)                                        
      IF(LEN.LT.LSR(2,LM+1)-1)THEN                                              
      WRITE(6,*)'LEN IS TOO SMALL',LEN                                          
      STOP 9                                                                    
      ENDIF                                                                     
      CALL EPSCAL(EPSI,LSR,LM)                                                  
      IR=LM-1                                                                   
   11 FORMAT(1X,3I5)                                                            
   12 FORMAT(1X,10E12.4)                                                        
C                                                                               
C     CALCULATE CONSTANTS FOR THE GAUSSIAN GRID                                 
C                                                                               
      CALL GAUSSG(ILATH,SL,WL,SIA,RAD,WOCS)                                     
      CALL TRIGL(ILATH,SL,WL,SIA,RAD,WOCS)
C
C     DLAT IS THE LATITUDE (IN DEGREES) OF THE CURRENT
C     GAUSSIAN ROW
C
      DO 96 J=1,ILAT
      DLAT(J)=180.0*RAD(J)/PI
      slat(j) = dlat(j) + 90.
   96 CONTINUE                                      
C
C
C     FIND FROM LSR ADDRESSES OF DESIRED MODES
C
      DO 43 IJ=1,LEN2
      INDEX(IJ)=0
      IRC(IJ)=0
   43 CONTINUE
      KOUNT=0
      DO 61 I=1,LM
      MN1=LSR(1,I)
      MN2=LSR(1,I+1)-1
      MS=I-1
      DO 61 MN=MN1,MN2
      NS=MS+MN-MN1
C
C     MODES ANTISYMMETRIC TO THE EQUATOR
C
      IF(MOD(MS+NS,2).EQ.1)THEN
C
C     ADDRESS OF THE REAL PART
C
      KOUNT=KOUNT+1
      INDEX(KOUNT)=MN
      IRC(KOUNT)=1
C
C     ADDRESS OF THE IMAGINARY PART FOR A NONZONAL COMPONENT
C
      IF(MS.NE.0)THEN
      KOUNT=KOUNT+1
      INDEX(KOUNT)=MN
      IRC(KOUNT)=2
      ENDIF
      ENDIF
   61 CONTINUE
      NINDEX=KOUNT
   91 FORMAT(1X,24I5)
      IF(NINDEX.NE.LEN2)THEN
      WRITE(6,*)'WRONG LEN2'
      STOP 9
      ENDIF
C
      DO 14 K=1,9
      DO 14 IJ=1,LA
      SM(IJ,K)=(0.0,0.0)
   14 CONTINUE

	 CALL LLIGG(GG,ILG1,ILAT,DLAT
     1 ,um,L,M,3)
	call GGAST (vor,LSR,LM,LA, GG,ILG1,ILAT,1,SL,WL,
     *   ALP,EPSI,WRKS,WRKL) 
c	call invlap (vor,vorinv,lsr,lm)
	call spfilt (vor,vorinv,lsr,lm)
      call stagg (gg,ilg1,ilat,1,sl,vorinv,lsr,lm,la,
     *            alp,epsi,wrks,wrkl)
CC Convert to Grid point
      call ggill (fll,l,m,gg,ilg1,ilat,slat,3)

      do 66 j = 1,37
      do 66 i = 1,73
      td(i,j) = fll(i,j)
   66 continue
	return
      END                                                                       

	
      SUBROUTINE SPFILT(SA,SB,LSR,LM)       
C
      COMPLEX SA(1),SB(1)
      INTEGER LSR(2,1)
      EARTH=6370949.0
      RAD2=EARTH*EARTH
	an0=10.
	ak=an0*(an0+1.)
      DO 12 I=1,LM
      MN1=LSR(1,I)
      MN2=LSR(1,I+1)-1
      MS=I-1
      DO 12 MN=MN1,MN2
      NS=MS+MN-MN1
      AN=FLOAT(NS)
cc      IF(MN.NE.1)SB(MN)=-SA(MN)*RAD2/(AN*(AN+1.0))
c      IF(MN.NE.1)SB(MN)=SA(MN)*exp(-an*(an+1.0)/ak)
	IF(MN.NE.1)SB(MN)=SA(MN)*exp(-0.00001*(an*an+an)**2)
   12 CONTINUE
      SB(1)=(0.0,0.0)
      RETURN
      END

